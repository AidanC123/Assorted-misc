Note; this file contains both output, and noted changes
input file: ToBuildAFire.txt
output:
[nltk_data] Downloading package treebank to
[nltk_data]     C:\Users\aconl\AppData\Roaming\nltk_data...
[nltk_data]   Package treebank is already up-to-date!
[nltk_data] Downloading package universal_tagset to
[nltk_data]     C:\Users\aconl\AppData\Roaming\nltk_data...
[nltk_data]   Package universal_tagset is already up-to-date!
[[('ï', 'JJ'), ('»', 'NNP'), ('¿Day', 'NNP'), ('had', 'VBD'), ('dawned', 'VBN'), ('cold', 'JJ'), ('and', 'CC'), ('gray', 'JJ'), ('the', 'DT'), ('man', 'NN'), ('turned', 'VBD'), ('aside', 'RB'), ('from', 'IN'), ('the', 'DT'), ('main', 'JJ'), ('Yukon', 'NNP'), ('trail', 'NN'), ('.', '.')], [('He', 'PRP'), ('climbed', 'VBD'), ('the', 'DT'), ('high', 'JJ'), ('earth-bank', 'NN'), ('where', 'WRB'), ('a', 'DT'), ('little-traveled', 'JJ'), ('trail', 'NN'), ('led', 'VBD'), ('east', 'RB'), ('through', 'IN'), ('the', 'DT'), ('pine', 'NN'), ('forest', 'NN'), ('.', '.')]]
('ï', 'JJ')
('»', 'NNP')
('¿Day', 'NNP')
('had', 'VBD')
('dawned', 'VBN')
('cold', 'JJ')
('and', 'CC')
('gray', 'JJ')
('the', 'DT')
('man', 'NN')
('turned', 'VBD')
('aside', 'RB')
('from', 'IN')
('the', 'DT')
('main', 'JJ')
('Yukon', 'NNP')
('trail', 'NN')
('.', '.')
('He', 'PRP')
('climbed', 'VBD')
('the', 'DT')
('high', 'JJ')
('earth-bank', 'NN')
('where', 'WRB')
('a', 'DT')
('little-traveled', 'JJ')
('trail', 'NN')
('led', 'VBD')
('east', 'RB')
('through', 'IN')
('the', 'DT')
('pine', 'NN')
('forest', 'NN')
('.', '.')
5776
1567
[('And', 'CC'), ('at', 'IN'), ('the', 'DT'), ('same', 'JJ'), ('time', 'NN')]
36
{'WRB', 'RBR', 'VBP', 'RBS', 'PDT', 'RP', ',', ':', 'NNS', '.', 'VBZ', 'JJS', 'TO', 'NN', 'CD', 'IN', 'VBD', 'MD', 'VB', 'NNP', 'DT', "''", 'RB', 'VBG', 'PRP', 'CC', '``', 'WDT', 'JJR', 'PRP$', 'WP', 'JJ', 'NNPS', 'POS', 'EX', 'VBN'}
[[0.         0.         0.         ... 0.         0.03125    0.        ]
 [0.         0.         0.         ... 0.         0.         0.        ]
 [0.         0.         0.         ... 0.         0.         0.        ]
 ...
 [0.         0.         0.         ... 0.         0.         0.        ]
 [0.         0.         0.         ... 0.         0.         0.05882353]
 [0.         0.         0.         ... 0.         0.         0.01075269]]
           WRB       RBR       VBP  ...      POS        EX       VBN
WRB   0.000000  0.000000  0.000000  ...  0.00000  0.031250  0.000000
RBR   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
VBP   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
RBS   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
PDT   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
RP    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
,     0.027907  0.000000  0.000000  ...  0.00000  0.013953  0.004651
:     0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
NNS   0.004464  0.004464  0.013393  ...  0.00000  0.000000  0.000000
.     0.019753  0.000000  0.000000  ...  0.00000  0.019753  0.000000
VBZ   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
JJS   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
TO    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
NN    0.006242  0.000000  0.002497  ...  0.01623  0.001248  0.009988
CD    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
IN    0.001678  0.000000  0.000000  ...  0.00000  0.003356  0.001678
VBD   0.005272  0.003515  0.000000  ...  0.00000  0.000000  0.087873
MD    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
VB    0.005525  0.005525  0.000000  ...  0.00000  0.000000  0.044199
NNP   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
DT    0.000000  0.003236  0.000000  ...  0.00000  0.000000  0.003236
''    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
RB    0.008876  0.002959  0.002959  ...  0.00000  0.002959  0.047337
VBG   0.010753  0.000000  0.000000  ...  0.00000  0.000000  0.043011
PRP   0.002096  0.000000  0.002096  ...  0.00000  0.000000  0.000000
CC    0.004587  0.004587  0.000000  ...  0.00000  0.004587  0.000000
``    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
WDT   0.000000  0.000000  0.043478  ...  0.00000  0.000000  0.000000
JJR   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
PRP$  0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
WP    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
JJ    0.003413  0.000000  0.000000  ...  0.00000  0.000000  0.003413
NNPS  0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
POS   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.000000
EX    0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.058824
VBN   0.000000  0.000000  0.000000  ...  0.00000  0.000000  0.010753

[36 rows x 36 columns]
Time taken in seconds:  4.782239198684692
Viterbi Algorithm Accuracy:  79.88165680473372
Time taken in seconds:  4.731306314468384
Viterbi Algorithm Accuracy:  91.12426035502959
[('Will', 'NN'), ('can', 'MD'), ('see', 'VB'), ('Marry', 'NN')]
[('Will', 'WRB'), ('can', 'WRB'), ('see', 'WRB'), ('Marry', 'WRB')]

changes:
line 6: added: from IPython.display import display
lines 18-27: added: code to change and format new corpus
textFile = open("ToBuildAFire.txt","r")
lines = textFile.readlines()
lines = lines[0]

sentences = sent_tokenize(lines)
corpus = []
for sentence in sentences:
    corpus.append(nltk.pos_tag(word_tokenize(sentence)))

nltk_data = corpus

line 48: changed: print(train_tagged_words[:5]) (print added)
lines 53-57: comment: explains some of result
#use_tags = ['NUM', 'PRT', 'CONJ', '.', 'DET', 'ADP', 'VERB', 'ADV', 'PRON', 'ADJ', 'X', 'NOUN']
#note; given matrices are slightly adjusted based on which tag is went thru first
#based on tags, the use_tags commented out is what the article writer uses by chance.
#doesn't change the final accuracy rating, the only thing that changes is that unknown words
#take whatever the first tag is (in articles case it is NUM)
lines 156-181: commented out: full code to test all sentences
lines 187-194: changed: patterns changed to better match new tokenization
    (r'.*ing$', 'VBG'),               # gerunds
    (r'.*ed$', 'VBD'),                # simple past
    (r'.*es$', 'VBZ'),                # 3rd singular present
    (r'.*ould$', 'MD'),               # modals
    (r'.*\'s$', 'NN$'),               # possessive nouns
    (r'.*s$', 'NNS'),                 # plural nouns
    (r'^-?[0-9]+(.[0-9]+)?$', 'CD'),  # cardinal numbers
    (r'.*', 'NN')                     # nouns (default)
