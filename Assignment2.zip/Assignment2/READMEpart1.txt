General README portion: this applies to all python files/parts, just run them in file and they should run, nothing required to add/remove from them.

Note; this file contains both output, and noted changes
output:
[nltk_data] Downloading package treebank to
[nltk_data]     C:\Users\aconl\AppData\Roaming\nltk_data...
[nltk_data]   Package treebank is already up-to-date!
[nltk_data] Downloading package universal_tagset to
[nltk_data]     C:\Users\aconl\AppData\Roaming\nltk_data...
[nltk_data]   Package universal_tagset is already up-to-date!
[[('Pierre', 'NOUN'), ('Vinken', 'NOUN'), (',', '.'), ('61', 'NUM'), ('years', 'NOUN'), ('old', 'ADJ'), (',', '.'), ('will', 'VERB'), ('join', 'VERB'), ('the', 'DET'), ('board', 'NOUN'), ('as', 'ADP'), ('a', 'DET'), ('nonexecutive', 'ADJ'), ('director', 'NOUN'), ('Nov.', 'NOUN'), ('29', 'NUM'), ('.', '.')], [('Mr.', 'NOUN'), ('Vinken', 'NOUN'), ('is', 'VERB'), ('chairman', 'NOUN'), ('of', 'ADP'), ('Elsevier', 'NOUN'), ('N.V.', 'NOUN'), (',', '.'), ('the', 'DET'), ('Dutch', 'NOUN'), ('publishing', 'VERB'), ('group', 'NOUN'), ('.', '.')]]
('Pierre', 'NOUN')
('Vinken', 'NOUN')
(',', '.')
('61', 'NUM')
('years', 'NOUN')
('old', 'ADJ')
(',', '.')
('will', 'VERB')
('join', 'VERB')
('the', 'DET')
('board', 'NOUN')
('as', 'ADP')
('a', 'DET')
('nonexecutive', 'ADJ')
('director', 'NOUN')
('Nov.', 'NOUN')
('29', 'NUM')
('.', '.')
('Mr.', 'NOUN')
('Vinken', 'NOUN')
('is', 'VERB')
('chairman', 'NOUN')
('of', 'ADP')
('Elsevier', 'NOUN')
('N.V.', 'NOUN')
(',', '.')
('the', 'DET')
('Dutch', 'NOUN')
('publishing', 'VERB')
('group', 'NOUN')
('.', '.')
80310
20366
[('Drink', 'NOUN'), ('Carrier', 'NOUN'), ('Competes', 'VERB'), ('With', 'ADP'), ('Cartons', 'NOUN')]
12
{'NUM', 'ADP', 'NOUN', 'PRON', 'DET', 'VERB', '.', 'X', 'ADJ', 'CONJ', 'PRT', 'ADV'}
[[1.84219927e-01 3.74866128e-02 3.51660132e-01 1.42806140e-03
  3.57015361e-03 2.07068902e-02 1.19243130e-01 2.02427700e-01
  3.53445187e-02 1.42806144e-02 2.60621198e-02 3.57015361e-03]
 [6.32751212e-02 1.69577319e-02 3.23588967e-01 6.96026310e-02
  3.20931405e-01 8.47886596e-03 3.87243740e-02 3.45482156e-02
  1.07061505e-01 1.01240189e-03 1.26550242e-03 1.45532778e-02]
 [9.14395228e-03 1.76826611e-01 2.62344331e-01 4.65906132e-03
  1.31063312e-02 1.49133503e-01 2.40094051e-01 2.88252197e-02
  1.25838192e-02 4.24540639e-02 4.39345129e-02 1.68945398e-02]
 [6.83371304e-03 2.23234631e-02 2.12756261e-01 6.83371304e-03
  9.56719834e-03 4.84738052e-01 4.19134386e-02 8.83826911e-02
  7.06150308e-02 5.01138950e-03 1.41230067e-02 3.69020514e-02]
 [2.28546783e-02 9.91806854e-03 6.35906279e-01 3.30602261e-03
  6.03708485e-03 4.02472317e-02 1.73925534e-02 4.51343954e-02
  2.06410810e-01 4.31220367e-04 2.87480245e-04 1.20741697e-02]
 [2.28360966e-02 9.23572779e-02 1.10589318e-01 3.55432779e-02
  1.33609578e-01 1.67955801e-01 3.48066315e-02 2.15930015e-01
  6.63904250e-02 5.43278083e-03 3.06629837e-02 8.38858187e-02]
 [7.82104954e-02 9.29084867e-02 2.18538776e-01 6.87694475e-02
  1.72191828e-01 8.96899477e-02 9.23720598e-02 2.56410260e-02
  4.61323895e-02 6.00793920e-02 2.78940029e-03 5.25694676e-02]
 [3.07514891e-03 1.42225638e-01 6.16951771e-02 5.41995019e-02
  5.68902567e-02 2.06419379e-01 1.60868734e-01 7.57255405e-02
  1.76821072e-02 1.03786280e-02 1.85085520e-01 2.57543717e-02]
 [2.17475723e-02 8.05825219e-02 6.96893215e-01 1.94174761e-04
  5.24271838e-03 1.14563107e-02 6.60194159e-02 2.09708735e-02
  6.33009672e-02 1.68932043e-02 1.14563107e-02 5.24271838e-03]
 [4.06147093e-02 5.59824370e-02 3.49066973e-01 6.03732169e-02
  1.23490669e-01 1.50384188e-01 3.51262353e-02 9.33040585e-03
  1.13611415e-01 5.48847427e-04 4.39077942e-03 5.70801310e-02]
 [5.67514673e-02 1.95694715e-02 2.50489235e-01 1.76125243e-02
  1.01369865e-01 4.01174158e-01 4.50097844e-02 1.21330721e-02
  8.29745606e-02 2.34833662e-03 1.17416831e-03 9.39334650e-03]
 [2.98681147e-02 1.19472459e-01 3.21955010e-02 1.20248254e-02
  7.13731572e-02 3.39022487e-01 1.39255241e-01 2.28859577e-02
  1.30721495e-01 6.98215654e-03 1.47401085e-02 8.14584941e-02]]
           NUM       ADP      NOUN  ...      CONJ       PRT       ADV
NUM   0.184220  0.037487  0.351660  ...  0.014281  0.026062  0.003570
ADP   0.063275  0.016958  0.323589  ...  0.001012  0.001266  0.014553
NOUN  0.009144  0.176827  0.262344  ...  0.042454  0.043935  0.016895
PRON  0.006834  0.022323  0.212756  ...  0.005011  0.014123  0.036902
DET   0.022855  0.009918  0.635906  ...  0.000431  0.000287  0.012074
VERB  0.022836  0.092357  0.110589  ...  0.005433  0.030663  0.083886
.     0.078210  0.092908  0.218539  ...  0.060079  0.002789  0.052569
X     0.003075  0.142226  0.061695  ...  0.010379  0.185086  0.025754
ADJ   0.021748  0.080583  0.696893  ...  0.016893  0.011456  0.005243
CONJ  0.040615  0.055982  0.349067  ...  0.000549  0.004391  0.057080
PRT   0.056751  0.019569  0.250489  ...  0.002348  0.001174  0.009393
ADV   0.029868  0.119472  0.032196  ...  0.006982  0.014740  0.081458

[12 rows x 12 columns]
Time taken in seconds:  37.167176485061646
Viterbi Algorithm Accuracy:  93.77990430622009
Time taken in seconds:  37.64144015312195
Viterbi Algorithm Accuracy:  97.1291866028708
[('Will', 'NOUN'), ('can', 'VERB'), ('see', 'VERB'), ('Marry', 'NOUN')]
[('Will', 'NUM'), ('can', 'VERB'), ('see', 'VERB'), ('Marry', 'NUM')]

changes:
line 6: added: from IPython.display import display
line 38: changed: print(train_tagged_words[:5]) (print added)
lines 43-47: comment: explains some of result
#use_tags = ['NUM', 'PRT', 'CONJ', '.', 'DET', 'ADP', 'VERB', 'ADV', 'PRON', 'ADJ', 'X', 'NOUN']
#note; given matrices are slightly adjusted based on which tag is went thru first
#based on tags, the use_tags commented out is what the article writer uses by chance.
#doesn't change the final accuracy rating, the only thing that changes is that unknown words
#take whatever the first tag is (in articles case it is NUM)
lines 146-171: commented out: full code to test all sentences